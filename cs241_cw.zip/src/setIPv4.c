#include "setIPv4.h"
#include "allocationValidation.h"

#include <stdlib.h>

// Initialises a set with the given capacity
struct IPv4Set* initIPv4Set(int capacity) {
    uint32_t* contents = (uint32_t*)calloc(capacity, 4);
    validateAlloc(contents, "Unable to allocate memory for set contents");

    struct IPv4Set* set = (struct IPv4Set*)malloc(sizeof(struct IPv4Set));
    validateAlloc(set, "Unable to allocate memory for set");

    set->size=0;
    set->cap = capacity;
    set->contents = contents;
    return set;
}

// Releases memory used by sets
void freeIpv4Set(struct IPv4Set* set) {
    free(set->contents);
    free(set);
}

// FNV-1a hash
uint32_t hashIPv4(uint32_t* IPv4) {
    uint32_t hash = 0x811c9dc5;
    int i;
    for (i=0; i<4; i++) {
        hash ^= *((uint8_t*)IPv4 + i);
        hash *= 0x01000193;
    }
    return hash;
}

void addIPv4(struct IPv4Set* set, uint32_t newIPv4);

// Doubles capacity of the set and rehashes all values
void rehashSet(struct IPv4Set* set) {
    uint32_t* oldContents = set->contents;
    set->cap *= 2;
    set->contents = (uint32_t*)calloc(set->cap, 4);
    validateAlloc(set->contents, "Unable to allocate memory to increase set capacity");

    set->size = 0;
    int i;
    for (i=0; i<set->cap/2; i++) {
        if (*(oldContents+i) != 0) {
            addIPv4(set, *(oldContents+i));
        }
    }
    free(oldContents);
}

// Add new values to set, doubling the size if load factor is too high
void addIPv4(struct IPv4Set* set, uint32_t newIPv4) {
    uint32_t hash = hashIPv4(&newIPv4);
    uint32_t* ptr = set->contents + (hash % set->cap);
    int i = 1;
    while (*ptr != 0) {
        if (*ptr == newIPv4) {
            return;
        }
        
        ptr = set->contents + ((hash + (i*i)) % set->cap);
        i += 1;
        // hash = hashIPv4(&hash);
        // ptr = set->contents + (hash % set->cap);
    }
    if (set->size+1 > set->cap/2) {
        rehashSet(set);
        addIPv4(set, newIPv4);
        return;
    }
    *ptr = newIPv4;
    set->size += 1;
}
