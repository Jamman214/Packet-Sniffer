#ifndef CS241_DISPATCH_H
#define CS241_DISPATCH_H

#include "setIPv4.h"
#include "stdint.h"
#include "LListArray32.h"

#include <pcap.h>
#include <pthread.h>

struct WorkQueue {
    struct WorkQueueElement* head;
    struct WorkQueueElement* tail;
    pthread_mutex_t lock;
    pthread_cond_t cond;
};

struct PacketData {
    struct pcap_pkthdr *header;
    u_char *packet;
};

struct WorkQueueElement {
    struct PacketData* packetData;
    struct WorkQueueElement* next;
};

struct IndividualData {
    pthread_t threadID;
    struct LListArray32 IPs;
    int SYNCount;
    int ARPCount;
    int blackListCount[2];
};

struct SharedData {
    struct WorkQueue queue;
    pthread_mutex_t terminate_lock;
    int terminate;
    pthread_mutex_t print_lock;
    int verbose;
};

struct ThreadData {
    struct IndividualData* individual;
    struct SharedData* shared;
};

struct PoolData {
    struct IndividualData* threads;
    struct SharedData* shared;
};

void dispatch(u_char *args, 
              const struct pcap_pkthdr *header, 
              const u_char *packet);

void freePoolData();

struct PoolData* initPool();

#endif
